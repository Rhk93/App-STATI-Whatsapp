package it.salvastati;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    // ================= TEMI =================
    static class Tema {
        String nome;
        int bg, surf, text, sub, accent, btnBg, btnText, seg, selBg, selText;
        int radius, thumbR;
        boolean apple, light;

        Tema(String nome, boolean apple, boolean light, int radius, int thumbR,
             String bg, String surf, String text, String sub, String accent,
             String btnBg, String btnText, String seg, String selBg, String selText) {
            this.nome = nome; this.apple = apple; this.light = light;
            this.radius = radius; this.thumbR = thumbR;
            this.bg = Color.parseColor(bg); this.surf = Color.parseColor(surf);
            this.text = Color.parseColor(text); this.sub = Color.parseColor(sub);
            this.accent = Color.parseColor(accent);
            this.btnBg = Color.parseColor(btnBg); this.btnText = Color.parseColor(btnText);
            this.seg = Color.parseColor(seg); this.selBg = Color.parseColor(selBg);
            this.selText = Color.parseColor(selText);
        }
    }

    static final Tema[] TEMI = {
        new Tema("Apple (iPhone)", true, true, 10, 10,
            "#F2F2F7", "#FFFFFF", "#000000", "#8E8E93", "#007AFF",
            "#FFFFFF", "#007AFF", "#E3E3E8", "#FFFFFF", "#000000"),
        new Tema("Apple scuro", true, false, 10, 10,
            "#000000", "#1C1C1E", "#FFFFFF", "#8E8E93", "#0A84FF",
            "#1C1C1E", "#0A84FF", "#2C2C2E", "#636366", "#FFFFFF"),
        new Tema("WhatsApp", false, true, 22, 6,
            "#FFFFFF", "#F0F2F5", "#111B21", "#667781", "#008069",
            "#008069", "#FFFFFF", "#E7F3EF", "#25D366", "#FFFFFF"),
        new Tema("Chiaro", false, true, 22, 6,
            "#FFFFFF", "#F1F3F4", "#202124", "#5F6368", "#1A73E8",
            "#1A73E8", "#FFFFFF", "#E8EAED", "#1A73E8", "#FFFFFF"),
        new Tema("Scuro", false, false, 22, 6,
            "#121212", "#1E1E1E", "#EEEEEE", "#AAAAAA", "#8AB4F8",
            "#2C2C2C", "#8AB4F8", "#2C2C2C", "#8AB4F8", "#121212"),
        new Tema("Rosa", false, true, 22, 12,
            "#FFF5F8", "#FFE4EC", "#3B1020", "#8A5A6A", "#D4537E",
            "#D4537E", "#FFFFFF", "#FBD3E0", "#D4537E", "#FFFFFF"),
    };

    static Tema tema(Context c) {
        int i = c.getSharedPreferences("p", MODE_PRIVATE).getInt("tema", 0);
        return TEMI[Math.max(0, Math.min(i, TEMI.length - 1))];
    }

    static GradientDrawable forma(int colore, float raggioPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(colore);
        g.setCornerRadius(raggioPx);
        return g;
    }

    @SuppressWarnings("deprecation")
    static void barre(Activity a, Tema t, int colore) {
        Window w = a.getWindow();
        w.setStatusBarColor(colore);
        w.setNavigationBarColor(colore);
        int f = 0;
        if (t.light && colore != Color.BLACK)
            f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        w.getDecorView().setSystemUiVisibility(f);
    }

    // ================= DATI =================
    static final String WA = "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses";
    static final String WAB = "primary:Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses";
    static final int REQ_TREE = 1;

    static class Item {
        Uri uri; String name; String mime; long date;
        boolean isVideo() { return mime != null && mime.startsWith("video"); }
    }

    final List<Item> all = new ArrayList<>();
    final List<Item> shown = new ArrayList<>();
    boolean showVideo = false;

    final ExecutorService pool = Executors.newFixedThreadPool(3);
    final Handler main = new Handler(Looper.getMainLooper());
    final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(30 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    SharedPreferences prefs;
    Tema T;
    GridView grid;
    TextView info, tFoto, tVideo;
    Adapter adapter;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        prefs = getSharedPreferences("p", MODE_PRIVATE);
        T = tema(this);
        barre(this, T, T.bg);
        int pad = dp(12);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(T.bg);
        root.setPadding(pad, dp(8), pad, 0);

        // --- barra titolo ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView titolo = new TextView(this);
        titolo.setText(T.apple ? "Stati" : "Salva Stati");
        titolo.setTextColor(T.text);
        titolo.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        titolo.setTextSize(T.apple ? 32 : 21);
        top.addView(titolo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView bTema = new TextView(this);
        bTema.setText("Tema");
        bTema.setTextSize(16);
        bTema.setTextColor(T.accent);
        bTema.setPadding(dp(12), dp(10), dp(4), dp(10));
        bTema.setOnClickListener(v -> sceltaTema());
        top.addView(bTema);
        root.addView(top);

        // --- pulsanti cartelle ---
        LinearLayout r1 = riga();
        r1.addView(pulsante("WhatsApp", v -> pick(WA)), peso());
        r1.addView(pulsante("WA Business", v -> pick(WAB)), peso());
        root.addView(r1);

        // --- schede Foto / Video (stile segmentato) ---
        LinearLayout seg = new LinearLayout(this);
        seg.setBackground(forma(T.seg, dp(T.apple ? 9 : T.radius)));
        seg.setPadding(dp(2), dp(2), dp(2), dp(2));
        tFoto = scheda("Foto", v -> { showVideo = false; filter(); });
        tVideo = scheda("Video", v -> { showVideo = true; filter(); });
        seg.addView(tFoto, peso());
        seg.addView(tVideo, peso());
        LinearLayout.LayoutParams lpSeg = new LinearLayout.LayoutParams(-1, -2);
        lpSeg.topMargin = dp(10);
        root.addView(seg, lpSeg);

        // --- info + salva tutti ---
        LinearLayout r3 = riga();
        r3.setGravity(Gravity.CENTER_VERTICAL);
        info = new TextView(this);
        info.setTextColor(T.sub);
        info.setTextSize(13);
        r3.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        TextView sTutti = new TextView(this);
        sTutti.setText("Salva tutti");
        sTutti.setTextColor(T.accent);
        sTutti.setTextSize(15);
        sTutti.setPadding(dp(10), dp(10), dp(4), dp(10));
        sTutti.setOnClickListener(v -> saveAll());
        r3.addView(sTutti);
        root.addView(r3);

        // --- griglia ---
        grid = new GridView(this);
        grid.setNumColumns(3);
        grid.setHorizontalSpacing(dp(T.apple ? 3 : 6));
        grid.setVerticalSpacing(dp(T.apple ? 3 : 6));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        adapter = new Adapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p, v, pos, id) -> {
            Item it = shown.get(pos);
            Intent i = new Intent(this, ViewerActivity.class);
            i.setData(it.uri);
            i.putExtra("mime", it.mime);
            i.putExtra("name", it.name);
            startActivity(i);
        });
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    void sceltaTema() {
        String[] nomi = new String[TEMI.length];
        for (int i = 0; i < TEMI.length; i++) nomi[i] = TEMI[i].nome;
        int cur = prefs.getInt("tema", 0);
        int stile = T.light ? android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
                : android.R.style.Theme_DeviceDefault_Dialog_Alert;
        new AlertDialog.Builder(this, stile)
                .setTitle("Scegli il tema")
                .setSingleChoiceItems(nomi, cur, (d, w) -> {
                    prefs.edit().putInt("tema", w).apply();
                    d.dismiss();
                    recreate();
                })
                .show();
    }

    // ---- scelta cartella ----
    void pick(String docId) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_TREE);
        Toast.makeText(this, "Premi \"Usa questa cartella\" e poi \"Consenti\"", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_TREE && res == RESULT_OK && data != null && data.getData() != null) {
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            prefs.edit().putString("tree", tree.toString()).apply();
            load();
        }
    }

    // ---- lettura stati ----
    void load() {
        String t = prefs.getString("tree", null);
        if (t == null) {
            all.clear(); filter();
            info.setText("Guarda gli stati in WhatsApp, poi premi \"WhatsApp\" qui sopra.");
            return;
        }
        Uri tree = Uri.parse(t);
        pool.execute(() -> {
            List<Item> list = new ArrayList<>();
            try {
                Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree,
                        DocumentsContract.getTreeDocumentId(tree));
                String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED};
                try (Cursor c = getContentResolver().query(kids, cols, null, null, null)) {
                    while (c != null && c.moveToNext()) {
                        String mime = c.getString(2);
                        if (mime == null || !(mime.startsWith("image") || mime.startsWith("video"))) continue;
                        Item it = new Item();
                        it.uri = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
                        it.name = c.getString(1);
                        it.mime = mime;
                        it.date = c.getLong(3);
                        list.add(it);
                    }
                }
            } catch (Exception e) {
                main.post(() -> info.setText("Accesso perso: premi di nuovo \"WhatsApp\"."));
                return;
            }
            list.sort((a, b) -> Long.compare(b.date, a.date));
            main.post(() -> { all.clear(); all.addAll(list); filter(); });
        });
    }

    void filter() {
        shown.clear();
        for (Item it : all) if (it.isVideo() == showVideo) shown.add(it);
        stileScheda(tFoto, !showVideo);
        stileScheda(tVideo, showVideo);
        if (prefs.getString("tree", null) != null)
            info.setText(shown.isEmpty()
                    ? "Nessuno stato trovato"
                    : shown.size() + (showVideo ? " video" : " foto"));
        adapter.notifyDataSetChanged();
    }

    void saveAll() {
        if (shown.isEmpty()) return;
        List<Item> copy = new ArrayList<>(shown);
        Toast.makeText(this, "Salvataggio in corso...", Toast.LENGTH_SHORT).show();
        pool.execute(() -> {
            int ok = 0;
            for (Item it : copy) if (save(this, it.uri, it.name, it.mime) != null) ok++;
            int n = ok;
            main.post(() -> Toast.makeText(this, n + " salvati nella Galleria", Toast.LENGTH_LONG).show());
        });
    }

    // ---- salvataggio in Galleria (usato anche dal visualizzatore) ----
    static Uri save(Context ctx, Uri src, String name, String mime) {
        boolean video = mime != null && mime.startsWith("video");
        ContentResolver cr = ctx.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, (video ? "Movies" : "Pictures") + "/Stati WhatsApp");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri coll = video
                ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri dst = null;
        try {
            dst = cr.insert(coll, v);
            if (dst == null) return null;
            try (InputStream in = cr.openInputStream(src); OutputStream out = cr.openOutputStream(dst)) {
                byte[] buf = new byte[65536];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            }
            v.clear();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            return dst;
        } catch (Exception e) {
            if (dst != null) try { cr.delete(dst, null, null); } catch (Exception ignored) { }
            return null;
        }
    }

    // ---- miniature ----
    Bitmap thumb(Item it) {
        try {
            if (it.isVideo()) {
                MediaMetadataRetriever m = new MediaMetadataRetriever();
                try {
                    m.setDataSource(this, it.uri);
                    Bitmap b = m.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 300, 300);
                    return b != null ? b : m.getFrameAtTime();
                } finally { m.release(); }
            } else {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(it.uri)) { BitmapFactory.decodeStream(in, null, o); }
                int sample = 1;
                while (o.outWidth / (sample * 2) >= 300 && o.outHeight / (sample * 2) >= 300) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                try (InputStream in = getContentResolver().openInputStream(it.uri)) { return BitmapFactory.decodeStream(in, null, o2); }
            }
        } catch (Exception e) { return null; }
    }

    class Adapter extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int p) { return shown.get(p); }
        public long getItemId(int p) { return p; }

        public View getView(int p, View cv, ViewGroup parent) {
            FrameLayout f = (FrameLayout) cv;
            ImageView img;
            TextView play;
            if (f == null) {
                f = new FrameLayout(MainActivity.this);
                int w = parent.getWidth() / 3;
                f.setLayoutParams(new GridView.LayoutParams(-1, w > 0 ? w : dp(110)));
                f.setBackground(forma(T.surf, dp(T.thumbR)));
                f.setClipToOutline(true);
                img = new ImageView(MainActivity.this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                f.addView(img, new FrameLayout.LayoutParams(-1, -1));
                play = new TextView(MainActivity.this);
                play.setText("▶");
                play.setTextSize(26);
                play.setTextColor(Color.WHITE);
                play.setShadowLayer(6, 0, 0, Color.BLACK);
                f.addView(play, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
            } else {
                img = (ImageView) f.getChildAt(0);
                play = (TextView) f.getChildAt(1);
            }
            Item it = shown.get(p);
            play.setVisibility(it.isVideo() ? View.VISIBLE : View.GONE);
            String key = it.uri.toString();
            final ImageView target = img;
            target.setTag(key);
            Bitmap b = cache.get(key);
            target.setImageBitmap(b);
            if (b == null) {
                pool.execute(() -> {
                    Bitmap t = thumb(it);
                    if (t == null) return;
                    cache.put(key, t);
                    main.post(() -> { if (key.equals(target.getTag())) target.setImageBitmap(t); });
                });
            }
            return f;
        }
    }

    // ---- elementi grafici a tema ----
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    LinearLayout riga() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setPadding(0, dp(6), 0, 0);
        return l;
    }

    LinearLayout.LayoutParams peso() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    TextView pulsante(String testo, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(testo);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(15);
        b.setTextColor(T.btnText);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        b.setBackground(forma(T.btnBg, dp(T.radius)));
        b.setOnClickListener(l);
        return b;
    }

    TextView scheda(String testo, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(testo);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(14);
        b.setPadding(0, dp(7), 0, dp(7));
        b.setOnClickListener(l);
        return b;
    }

    void stileScheda(TextView b, boolean attiva) {
        if (attiva) {
            b.setBackground(forma(T.selBg, dp(T.apple ? 7 : T.radius)));
            b.setTextColor(T.selText);
            b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        } else {
            b.setBackground(null);
            b.setTextColor(T.apple ? T.text : T.sub);
            b.setTypeface(Typeface.DEFAULT);
        }
    }
}
