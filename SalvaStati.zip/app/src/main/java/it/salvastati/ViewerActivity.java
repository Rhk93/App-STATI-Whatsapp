package it.salvastati;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.InputStream;

public class ViewerActivity extends Activity {

    Uri src, saved;
    String mime, name;
    MainActivity.Tema T;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        src = getIntent().getData();
        mime = getIntent().getStringExtra("mime");
        name = getIntent().getStringExtra("name");
        T = MainActivity.tema(this);
        MainActivity.barre(this, T, Color.BLACK);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        if (mime != null && mime.startsWith("video")) {
            VideoView vv = new VideoView(this);
            MediaController mc = new MediaController(this);
            mc.setAnchorView(vv);
            vv.setMediaController(mc);
            vv.setVideoURI(src);
            vv.setOnPreparedListener(mp -> { mp.setLooping(true); vv.start(); });
            root.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        } else {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setImageBitmap(load());
            root.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        }

        // barra in alto: "Fine" a sinistra, Salva e Condividi a destra
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.argb(150, 0, 0, 0));
        bar.setPadding(dp(8), dp(28), dp(8), dp(8));
        bar.addView(tasto(T.apple ? "Fine" : "Indietro", v -> finish()));
        bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        bar.addView(tasto("Salva", v -> doSave(false)));
        bar.addView(tasto("Condividi", v -> doSave(true)));
        root.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        setContentView(root);
    }

    TextView tasto(String testo, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(testo);
        b.setTextSize(16);
        b.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        if (T.apple) {
            // stile iPhone: solo testo blu
            b.setTextColor(T.accent);
            b.setPadding(dp(8), dp(8), dp(8), dp(8));
        } else {
            b.setTextColor(Color.WHITE);
            b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            b.setPadding(dp(14), dp(8), dp(14), dp(8));
            b.setBackground(MainActivity.forma(T.accent, dp(T.radius)));
        }
        b.setOnClickListener(l);
        return b;
    }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Bitmap load() {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(src)) { BitmapFactory.decodeStream(in, null, o); }
            int max = Math.max(getResources().getDisplayMetrics().widthPixels,
                    getResources().getDisplayMetrics().heightPixels);
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= max) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            try (InputStream in = getContentResolver().openInputStream(src)) { return BitmapFactory.decodeStream(in, null, o2); }
        } catch (Exception e) { return null; }
    }

    void doSave(boolean share) {
        if (saved == null) saved = MainActivity.save(this, src, name, mime);
        if (saved == null) {
            Toast.makeText(this, "Errore nel salvataggio", Toast.LENGTH_LONG).show();
            return;
        }
        if (share) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, saved);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, "Condividi"));
        } else {
            Toast.makeText(this, "Salvato nella Galleria (Stati WhatsApp)", Toast.LENGTH_SHORT).show();
        }
    }
}
